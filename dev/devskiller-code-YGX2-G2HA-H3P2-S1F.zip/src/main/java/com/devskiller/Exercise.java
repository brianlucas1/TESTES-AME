package com.devskiller;

import java.util.List;

public class Exercise {

    public List<Integer> findDuplicates(List<Integer> integers, int numberOfDuplicates) {
        return null;
    }

}
